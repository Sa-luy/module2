<?php

$username = 'root';
$password = '';
$conn = new PDO('mysql:host=localhost;dbname=goods', $username, $password);